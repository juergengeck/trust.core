import type { ProfileResponse } from './recipes/ProfileResponse.js';
import type { ConnectionAckCertificate } from './recipes/ConnectionAckCertificate.js';

declare module '@OneObjectInterfaces' {
    export interface OneUnversionedObjectInterfaces {
        ProfileResponse: ProfileResponse;
    }

    export interface OneIdObjectInterfaces {
        ConnectionAckCertificate: Pick<ConnectionAckCertificate, 'id' | '$type$'>;
    }

    export interface OneVersionedObjectInterfaces {
        ConnectionAckCertificate: ConnectionAckCertificate;
    }
}
