/**
 * TrustModel - Trust and identity management with ONE.core integration
 *
 * This model orchestrates trust relationships by integrating:
 * - TrustRelationship objects (ONE.core versioned storage)
 * - TrustedKeysManager (ONE.models certificate validation)
 * - Verifiable Credentials (exportable trust attestations)
 *
 * Architecture:
 * - Trust relationships stored as ONE.core versioned objects
 * - Key trust validated via TrustKeysCertificate
 * - Trust chains exportable as VCs
 */
import { Model } from '@refinio/one.models/lib/models/Model.js';
import { OEvent } from '@refinio/one.models/lib/misc/OEvent.js';
import { StateMachine } from '@refinio/one.models/lib/misc/StateMachine.js';
import { SHA256IdHash } from '@refinio/one.core/lib/util/type-checks.js';
import type { Person } from '@refinio/one.core/lib/recipes.js';
import type LeuteModel from '@refinio/one.models/lib/models/Leute/LeuteModel.js';
import type TrustedKeysManager from '@refinio/one.models/lib/models/Leute/TrustedKeysManager.js';
import type { DeviceCredentials, TrustStatus, TrustEntry, TrustLevel, TrustEvaluation, TrustChain } from '../types/trust-types.js';
/**
 * TrustModel - Manages trust relationships with ONE.core storage
 *
 * Dependencies injected via constructor:
 * - LeuteModel (identity management)
 * - TrustedKeysManager (certificate validation)
 */
export declare class TrustModel implements Model {
    readonly onUpdated: OEvent<() => void>;
    readonly onTrustChanged: OEvent<(deviceId: SHA256IdHash<Person>, status: TrustStatus) => void>;
    readonly onCredentialsUpdated: OEvent<(deviceId: SHA256IdHash<Person>) => void>;
    state: StateMachine<'Uninitialised' | 'Initialised', 'shutdown' | 'init'>;
    private leuteModel;
    private trustedKeysManager?;
    private deviceCredentials?;
    constructor(leuteModel: LeuteModel, trustedKeysManager?: TrustedKeysManager);
    /**
     * Initialize the TrustModel
     */
    init(): Promise<void>;
    /**
     * Shutdown the TrustModel
     */
    shutdown(): Promise<void>;
    /**
     * Get device credentials for the current device
     */
    getDeviceCredentials(): DeviceCredentials | undefined;
    /**
     * Set device identity for external systems (like DeviceDiscoveryModel)
     */
    setDeviceIdentity(targetSystem: any): Promise<void>;
    /**
     * Add or update a trust relationship
     * Stores as ONE.core versioned object
     */
    setTrustStatus(deviceId: SHA256IdHash<Person>, publicKey: string, status: TrustStatus, options?: {
        trustLevel?: TrustLevel;
        permissions?: any;
        reason?: string;
        context?: string;
        verificationMethod?: string;
    }): Promise<void>;
    /**
     * Get trust status for a device
     * Queries ONE.core via reverse map
     */
    getTrustStatus(deviceId: SHA256IdHash<Person>): Promise<TrustStatus | undefined>;
    /**
     * Get all trusted devices
     */
    getTrustedDevices(): Promise<TrustEntry[]>;
    /**
     * Verify a device's public key
     * Checks both TrustRelationship AND TrustedKeysManager certificates
     */
    verifyDeviceKey(deviceId: SHA256IdHash<Person>, publicKey: string): Promise<boolean>;
    /**
     * Evaluate trust level for a person/device
     * Sophisticated trust scoring considering relationships AND certificates
     */
    evaluateTrust(personId: SHA256IdHash<Person>, context?: 'general' | 'file-transfer' | 'communication'): Promise<TrustEvaluation>;
    /**
     * Set trust level for a person
     * Convenience method for setting trust level with 'trusted' status
     */
    setTrustLevel(personId: SHA256IdHash<Person>, trustLevel: TrustLevel, establishedBy?: SHA256IdHash<Person>, reason?: string): Promise<void>;
    /**
     * Get trust level for a person
     */
    getTrustLevel(personId: SHA256IdHash<Person>): Promise<TrustLevel | undefined>;
    /**
     * Get trust chain for a person (for chain of trust visualization)
     * Builds a tree of trust relationships starting from self
     */
    getTrustChain(personId: SHA256IdHash<Person>, maxDepth?: number): Promise<TrustChain>;
    /**
     * Recursively build trust chain tree
     */
    private buildTrustChainRecursive;
    /**
     * Get TrustRelationship object from ONE.core storage
     */
    private getTrustRelationshipObject;
    /**
     * Get all TrustRelationship objects
     */
    private getAllTrustRelationships;
    /**
     * Initialize device credentials from one.core's secure keychain
     */
    private initializeDeviceCredentials;
    /**
     * Get device credentials from one.core's secure keychain
     */
    private getDeviceCredentialsFromKeychain;
    /**
     * Get crypto API for signing operations
     */
    getCryptoApi(personId: SHA256IdHash<Person>): Promise<any>;
    /**
     * Share topic access with participants
     *
     * After creating a group topic, this method ensures all participants can access it via CHUM by:
     * 1. Getting the access Group that controls topic visibility
     * 2. Granting each participant access to that Group via Certificates
     * 3. Sharing the Group and Certificates via CHUM
     *
     * @param topicId - The topic ID (also used as channelId)
     * @param participants - Array of participant personIds
     */
    shareTopicAccessWithParticipants(topicId: string, participants: SHA256IdHash<Person>[]): Promise<void>;
    /**
     * Get the access Group for a topic
     *
     * Topics use Groups to control who can see them. This method retrieves
     * the Group ID that was created when addPersonsToTopic was called.
     */
    private getTopicAccessGroup;
    /**
     * Grant a person access to a Group via Certificate
     *
     * Creates a Certificate that proves the person is a member of the Group.
     * The Certificate is automatically shared via CHUM.
     *
     * TODO: Re-implement using CAModel certificate issuance
     */
    private grantGroupAccess;
}
//# sourceMappingURL=TrustModel.d.ts.map