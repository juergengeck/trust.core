/**
 * CAModel - Certificate Authority Model
 *
 * Manages certificate issuance, revocation, and lifecycle for a ONE instance acting as a CA.
 * Every ONE instance can be a Certificate Authority with its own root certificate.
 */
import type { SHA256Hash, SHA256IdHash } from '@refinio/one.core/lib/util/type-checks.js';
import type { Person } from '@refinio/one.core/lib/recipes.js';
import type { Certificate, CertificateType } from '../recipes/Certificate.js';
import type { TrustKeysCertificate } from '../recipes/TrustKeysCertificate.js';
/**
 * Certificate Issuance Options
 */
export interface CertificateIssueOptions {
    certificateType: CertificateType;
    subject: SHA256IdHash<Person> | string;
    subjectPublicKey: string;
    validityDays?: number;
    chainDepth?: number;
    issuedBy?: SHA256Hash<Certificate>;
    claims?: Record<string, any>;
}
/**
 * Certificate Extension Options
 */
export interface CertificateExtendOptions {
    certificateId: string;
    additionalDays: number;
}
/**
 * Certificate Revocation Options
 */
export interface CertificateRevokeOptions {
    certificateId: string;
    reason?: string;
}
/**
 * CAModel
 *
 * Platform-agnostic Certificate Authority operations.
 * Manages the full certificate lifecycle using ONE.core storage and versioning.
 */
export declare class CAModel {
    private oneCore;
    private instanceId;
    private instancePublicKey;
    private rootCertificate;
    private serialNumberCounter;
    constructor(oneCore: any);
    /**
     * Initialize the CA Model
     * Loads or creates root certificate
     */
    init(): Promise<void>;
    /**
     * Create root certificate for this CA instance
     */
    private createRootCertificate;
    /**
     * Load existing root certificate
     */
    private loadRootCertificate;
    /**
     * Issue a new certificate
     */
    issueCertificate(options: CertificateIssueOptions): Promise<SHA256Hash<Certificate>>;
    /**
     * Issue a device trust certificate (TrustKeysCertificate)
     */
    issueDeviceCertificate(subject: SHA256IdHash<Person>, subjectPublicKey: string, options?: {
        trustLevel?: 'full' | 'limited' | 'temporary';
        permissions?: Record<string, boolean>;
        validityDays?: number;
        trustReason?: string;
        verificationMethod?: string;
    }): Promise<SHA256Hash<TrustKeysCertificate>>;
    /**
     * Extend a certificate's validity
     * Creates a new version with extended validUntil
     */
    extendCertificate(options: CertificateExtendOptions): Promise<SHA256Hash<Certificate>>;
    /**
     * Reduce a certificate's validity
     * Creates a new version with earlier validUntil
     */
    reduceCertificate(certificateId: string, newValidUntil: number): Promise<SHA256Hash<Certificate>>;
    /**
     * Revoke a certificate
     * Creates a new version with status='revoked' and validUntil in the past
     */
    revokeCertificate(options: CertificateRevokeOptions): Promise<SHA256Hash<Certificate>>;
    /**
     * Get certificate by ID
     */
    getCertificate(certificateId: string): Promise<Certificate | null>;
    /**
     * Get all versions of a certificate (audit trail)
     */
    getCertificateHistory(certificateId: string): Promise<Certificate[]>;
    /**
     * Verify certificate validity
     */
    verifyCertificate(certificate: Certificate): Promise<{
        valid: boolean;
        reason?: string;
    }>;
    /**
     * Get root certificate
     */
    getRootCertificate(): Certificate | null;
    /**
     * Generate unique serial number
     */
    private generateSerialNumber;
    /**
     * Shutdown the CA Model
     */
    shutdown(): Promise<void>;
}
//# sourceMappingURL=CAModel.d.ts.map