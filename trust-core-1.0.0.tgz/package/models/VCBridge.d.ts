/**
 * VCBridge - Verifiable Credential Bridge
 *
 * Bidirectional conversion between ONE.core Certificates and W3C Verifiable Credentials.
 * Provides structural compatibility in both directions:
 * - Certificate → VC (for external presentation)
 * - VC → Certificate (for internal storage)
 */
import type { SHA256Hash, SHA256IdHash } from '@refinio/one.core/lib/util/type-checks.js';
import type { Certificate } from '../recipes/Certificate.js';
import type { TrustKeysCertificate } from '../recipes/TrustKeysCertificate.js';
import type { VerifiableCredential } from '../recipes/VerifiableCredential.js';
/**
 * DID Method for ONE Platform
 * Format: did:one:sha256:<hash>
 */
export declare class DIDConverter {
    /**
     * Convert SHA256IdHash to DID
     */
    static hashToDID(hash: SHA256IdHash<any> | SHA256Hash<any>): string;
    /**
     * Convert DID to SHA256Hash
     */
    static didToHash(did: string): SHA256IdHash<any> | SHA256Hash<any> | null;
    /**
     * Check if string is a valid DID
     */
    static isValidDID(did: string): boolean;
}
/**
 * Ed25519 Proof Converter
 */
export declare class ProofConverter {
    /**
     * Convert ONE.core signature to W3C Ed25519Signature2020 proof
     */
    static toW3CProof(signature: string, issuerDID: string, created?: number): {
        type: string;
        created: string;
        proofPurpose: string;
        verificationMethod: string;
        proofValue: string;
    };
    /**
     * Convert W3C Ed25519Signature2020 proof to ONE.core signature
     */
    static fromW3CProof(proof: {
        type: string;
        proofValue: string;
    }): string | null;
}
/**
 * VCBridge
 *
 * Converts between Certificate and VerifiableCredential formats
 */
export declare class VCBridge {
    /**
     * Convert Certificate to Verifiable Credential
     */
    static certificateToVC(cert: Certificate): VerifiableCredential;
    /**
     * Convert TrustKeysCertificate to Verifiable Credential
     */
    static trustKeysCertificateToVC(cert: TrustKeysCertificate): VerifiableCredential;
    /**
     * Convert Verifiable Credential to Certificate
     */
    static vcToCertificate(vc: VerifiableCredential): Certificate;
    /**
     * Convert Verifiable Credential to TrustKeysCertificate
     */
    static vcToTrustKeysCertificate(vc: VerifiableCredential): TrustKeysCertificate;
    /**
     * Export certificate as JSON-LD (for external sharing)
     */
    static exportAsJsonLD(cert: Certificate | TrustKeysCertificate): string;
    /**
     * Import from JSON-LD (external VC)
     */
    static importFromJsonLD(jsonLD: string): VerifiableCredential;
}
//# sourceMappingURL=VCBridge.d.ts.map