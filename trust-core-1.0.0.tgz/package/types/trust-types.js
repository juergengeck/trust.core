/**
 * Trust Core Type Definitions
 *
 * Platform-agnostic types for trust relationships, device identity,
 * and credential management across LAMA applications.
 */
export {};
//# sourceMappingURL=trust-types.js.map