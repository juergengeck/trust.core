/**
 * AuditTrailService
 *
 * Tracks and queries certificate usage for audit purposes.
 * Maintains complete history of certificate operations and trust decisions.
 */
import type { SHA256Hash, SHA256IdHash } from '@refinio/one.core/lib/util/type-checks.js';
import type { Person } from '@refinio/one.core/lib/recipes.js';
import type { Certificate } from '../recipes/Certificate.js';
/**
 * Audit Event Types
 */
export type AuditEventType = 'certificate_issued' | 'certificate_extended' | 'certificate_reduced' | 'certificate_revoked' | 'certificate_verified' | 'trust_established' | 'trust_revoked' | 'vc_exported' | 'vc_imported' | 'memory_imported' | 'memory_exported';
/**
 * Audit Event
 */
export interface AuditEvent {
    $type$: 'AuditEvent';
    eventType: AuditEventType;
    timestamp: number;
    actor: SHA256IdHash<Person>;
    subject?: SHA256IdHash<Person> | string;
    certificateId?: string;
    certificateHash?: SHA256Hash<Certificate>;
    certificateVersion?: number;
    reason?: string;
    metadata?: Record<string, any>;
    success: boolean;
    error?: string;
}
/**
 * Audit Query Options
 */
export interface AuditQueryOptions {
    eventType?: AuditEventType | AuditEventType[];
    actor?: SHA256IdHash<Person>;
    subject?: SHA256IdHash<Person> | string;
    certificateId?: string;
    startTime?: number;
    endTime?: number;
    limit?: number;
    offset?: number;
}
/**
 * AuditTrailService
 *
 * Platform-agnostic audit trail management.
 * Stores audit events in ONE.core for synchronization and persistence.
 */
export declare class AuditTrailService {
    private oneCore;
    private events;
    constructor(oneCore: any);
    /**
     * Initialize the service
     */
    init(): Promise<void>;
    /**
     * Record an audit event
     */
    recordEvent(event: Omit<AuditEvent, '$type$' | 'timestamp'>): Promise<void>;
    /**
     * Query audit events
     */
    queryEvents(options?: AuditQueryOptions): Promise<AuditEvent[]>;
    /**
     * Get certificate audit trail (all events for a specific certificate)
     */
    getCertificateAuditTrail(certificateId: string): Promise<AuditEvent[]>;
    /**
     * Get actor audit trail (all events by a specific actor)
     */
    getActorAuditTrail(actor: SHA256IdHash<Person>): Promise<AuditEvent[]>;
    /**
     * Load recent events from storage
     */
    private loadRecentEvents;
    /**
     * Clear old events from cache (keep last N days)
     */
    pruneOldEvents(daysToKeep?: number): Promise<void>;
    /**
     * Shutdown the service
     */
    shutdown(): Promise<void>;
}
//# sourceMappingURL=AuditTrailService.d.ts.map