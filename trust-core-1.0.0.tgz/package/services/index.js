/**
 * Service Exports
 */
export { AuditTrailService } from './AuditTrailService.js';
export { VCPropagationService } from './VCPropagationService.js';
// HandshakeService
export { HandshakeService, handshakeService } from './HandshakeService.js';
//# sourceMappingURL=index.js.map