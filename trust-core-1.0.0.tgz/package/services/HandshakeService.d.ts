/**
 * HandshakeService
 *
 * Handles ProfileResponse/ConnectionAckCertificate handshake flow.
 * Creates and validates handshake objects for peer discovery.
 */
import type { CryptoApi } from '@refinio/one.core/lib/crypto/CryptoApi.js';
import type { SHA256Hash, SHA256IdHash } from '@refinio/one.core/lib/util/type-checks.js';
import type { Person } from '@refinio/one.core/lib/recipes.js';
import type { Profile } from '@refinio/one.models/lib/recipes/Leute/Profile.js';
import type { License } from '@refinio/one.models/lib/recipes/Certificates/License.js';
import type { PublicKey } from '@refinio/one.core/lib/crypto/encryption.js';
import type { ProfileResponse } from '../recipes/ProfileResponse.js';
import type { ConnectionAckCertificate } from '../recipes/ConnectionAckCertificate.js';
export interface CreateProfileResponseParams {
    responder: SHA256IdHash<Person>;
    challenger: SHA256IdHash<Person>;
    challengerProfile: SHA256Hash<Profile>;
    challengerPublicKey: PublicKey;
    cryptoApi: CryptoApi;
}
export interface CreateConnectionAckParams {
    profileResponse: ProfileResponse;
    profileResponseHash: SHA256Hash<ProfileResponse>;
    responderPublicKey: PublicKey;
    cryptoApi: CryptoApi;
    license: SHA256Hash<License>;
    validityDurationMs?: number;
}
export declare class HandshakeService {
    /**
     * Create a ProfileResponse with encrypted nonce.
     * Called by the RESPONDER (the one who wants to connect to the challenger).
     * Uses NaCl box encryption: shared secret derived from (responder's private key, challenger's public key).
     */
    createProfileResponse(params: CreateProfileResponseParams): Promise<{
        response: ProfileResponse;
        hash: SHA256Hash<ProfileResponse>;
        nonce: Uint8Array;
    }>;
    /**
     * Verify and acknowledge a ProfileResponse by decrypting the nonce.
     * Called by the CHALLENGER (the one who advertised their profile).
     * Uses NaCl box decryption: shared secret derived from (challenger's private key, responder's public key).
     */
    verifyAndAcknowledge(params: CreateConnectionAckParams): Promise<{
        certificate: ConnectionAckCertificate;
        hash: SHA256Hash<ConnectionAckCertificate>;
    } | null>;
}
export declare const handshakeService: HandshakeService;
//# sourceMappingURL=HandshakeService.d.ts.map