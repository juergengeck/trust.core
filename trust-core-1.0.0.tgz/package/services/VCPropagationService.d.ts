/**
 * VCPropagationService
 *
 * Manages dual propagation of certificates:
 * 1. Internal: ONE.core sync via CHUM
 * 2. External: VC documents shared via HTTP/HTTPS
 */
import type { SHA256Hash } from '@refinio/one.core/lib/util/type-checks.js';
import type { Certificate } from '../recipes/Certificate.js';
/**
 * Propagation Status
 */
export type PropagationStatus = 'pending' | 'syncing' | 'synced' | 'failed' | 'offline';
/**
 * Propagation Record
 */
export interface PropagationRecord {
    certificateId: string;
    certificateHash: SHA256Hash<Certificate>;
    internalStatus: PropagationStatus;
    internalSyncedAt?: number;
    internalError?: string;
    externalStatus: PropagationStatus;
    externalUrl?: string;
    externalSyncedAt?: number;
    externalError?: string;
    createdAt: number;
    updatedAt: number;
}
/**
 * VCPropagationService
 *
 * Manages certificate propagation across ONE.core network and external systems.
 * Ensures certificates are synchronized and verifiable by all parties.
 */
export declare class VCPropagationService {
    private oneCore;
    private propagationQueue;
    private isRunning;
    private syncInterval;
    constructor(oneCore: any);
    /**
     * Initialize the service
     */
    init(): Promise<void>;
    /**
     * Queue a certificate for propagation
     */
    queueForPropagation(certificateId: string, certificateHash: SHA256Hash<Certificate>, options?: {
        internalOnly?: boolean;
        externalUrl?: string;
    }): Promise<void>;
    /**
     * Get propagation status for a certificate
     */
    getPropagationStatus(certificateId: string): PropagationRecord | null;
    /**
     * Process propagation queue
     */
    private processPropagationQueue;
    /**
     * Propagate certificate internally via ONE.core sync
     */
    private propagateInternal;
    /**
     * Propagate certificate externally as VC document
     */
    private propagateExternal;
    /**
     * Retry failed propagations
     */
    retryFailed(): Promise<void>;
    /**
     * Start background sync process
     */
    private startBackgroundSync;
    /**
     * Stop background sync process
     */
    private stopBackgroundSync;
    /**
     * Load propagation state from storage
     */
    private loadPropagationState;
    /**
     * Save propagation state to storage
     */
    private savePropagationState;
    /**
     * Shutdown the service
     */
    shutdown(): Promise<void>;
}
//# sourceMappingURL=VCPropagationService.d.ts.map