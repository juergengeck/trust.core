/**
 * Service Exports
 */
export { AuditTrailService, AuditEvent, AuditEventType, AuditQueryOptions } from './AuditTrailService.js';
export { VCPropagationService, PropagationStatus, PropagationRecord } from './VCPropagationService.js';
export { HandshakeService, handshakeService, type CreateProfileResponseParams, type CreateConnectionAckParams } from './HandshakeService.js';
//# sourceMappingURL=index.d.ts.map