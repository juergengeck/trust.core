/**
 * HandshakeService
 *
 * Handles ProfileResponse/ConnectionAckCertificate handshake flow.
 * Creates and validates handshake objects for peer discovery.
 */
import { storeUnversionedObject } from '@refinio/one.core/lib/storage-unversioned-objects.js';
import { storeVersionedObject } from '@refinio/one.core/lib/storage-versioned-objects.js';
import { createRandomNonce } from '@refinio/one.core/lib/crypto/encryption.js';
/**
 * Convert Uint8Array to hex string
 */
function toHex(bytes) {
    return Array.from(bytes)
        .map(b => b.toString(16).padStart(2, '0'))
        .join('');
}
/**
 * Convert hex string to Uint8Array
 */
function fromHex(hex) {
    const bytes = new Uint8Array(hex.length / 2);
    for (let i = 0; i < hex.length; i += 2) {
        bytes[i / 2] = parseInt(hex.substring(i, i + 2), 16);
    }
    return bytes;
}
export class HandshakeService {
    /**
     * Create a ProfileResponse with encrypted nonce.
     * Called by the RESPONDER (the one who wants to connect to the challenger).
     * Uses NaCl box encryption: shared secret derived from (responder's private key, challenger's public key).
     */
    async createProfileResponse(params) {
        const { responder, challenger, challengerProfile, challengerPublicKey, cryptoApi } = params;
        // Generate random nonce
        const nonce = createRandomNonce();
        // Encrypt nonce with challenger's public key
        const encryptedNonce = cryptoApi.encryptAndEmbedNonce(nonce, challengerPublicKey);
        const response = {
            $type$: 'ProfileResponse',
            responder,
            challenger,
            challengerProfile,
            encryptedNonce: toHex(encryptedNonce),
            created: Date.now()
        };
        const result = await storeUnversionedObject(response);
        return {
            response,
            hash: result.hash,
            nonce
        };
    }
    /**
     * Verify and acknowledge a ProfileResponse by decrypting the nonce.
     * Called by the CHALLENGER (the one who advertised their profile).
     * Uses NaCl box decryption: shared secret derived from (challenger's private key, responder's public key).
     */
    async verifyAndAcknowledge(params) {
        const { profileResponse, profileResponseHash, responderPublicKey, cryptoApi, license, validityDurationMs = 365 * 24 * 60 * 60 * 1000 // 1 year default
         } = params;
        try {
            // Decrypt the nonce using challenger's CryptoApi and responder's public key
            // NaCl box: derives shared secret from (myPrivateKey, theirPublicKey)
            const encryptedNonce = fromHex(profileResponse.encryptedNonce);
            const decryptedNonce = cryptoApi.decryptWithEmbeddedNonce(encryptedNonce, responderPublicKey);
            const now = Date.now();
            const id = `connack:${profileResponse.responder}:${profileResponse.challenger}:${now}`;
            const certificate = {
                $type$: 'ConnectionAckCertificate',
                id,
                responder: profileResponse.responder,
                challenger: profileResponse.challenger,
                nonce: toHex(decryptedNonce),
                profileResponse: profileResponseHash,
                created: now,
                status: 'valid',
                license,
                validUntil: now + validityDurationMs,
                version: 1
            };
            const result = await storeVersionedObject(certificate);
            return {
                certificate,
                hash: result.hash
            };
        }
        catch (error) {
            console.error('[HandshakeService] Failed to verify ProfileResponse:', error);
            return null;
        }
    }
}
export const handshakeService = new HandshakeService();
//# sourceMappingURL=HandshakeService.js.map