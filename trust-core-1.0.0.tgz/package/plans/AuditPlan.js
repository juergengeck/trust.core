/**
 * AuditPlan - Audit Trail Plan
 *
 * RPC-style plan for audit trail operations.
 * Provides transport-agnostic interface for audit event tracking and queries.
 */
/**
 * AuditPlan
 *
 * Transport-agnostic audit trail operations.
 * Designed for use with IPC, HTTP, or other RPC mechanisms.
 */
export class AuditPlan {
    auditService;
    constructor(auditService) {
        this.auditService = auditService;
    }
    /**
     * Record an audit event
     */
    async recordEvent(request) {
        try {
            await this.auditService.recordEvent({
                eventType: request.eventType,
                actor: request.actor,
                subject: request.subject,
                certificateId: request.certificateId,
                certificateHash: request.certificateHash,
                certificateVersion: request.certificateVersion,
                reason: request.reason,
                metadata: request.metadata,
                success: request.success,
                error: request.error
            });
            return { success: true };
        }
        catch (error) {
            console.error('[AuditPlan] Error recording event:', error);
            return {
                success: false,
                error: error instanceof Error ? error.message : 'Unknown error'
            };
        }
    }
    /**
     * Query audit events
     */
    async queryEvents(request) {
        try {
            const events = await this.auditService.queryEvents(request.options);
            return { events };
        }
        catch (error) {
            console.error('[AuditPlan] Error querying events:', error);
            return {
                events: [],
                error: error instanceof Error ? error.message : 'Unknown error'
            };
        }
    }
    /**
     * Get audit trail for a specific certificate
     */
    async getCertificateAuditTrail(request) {
        try {
            const events = await this.auditService.getCertificateAuditTrail(request.certificateId);
            return { events };
        }
        catch (error) {
            console.error('[AuditPlan] Error getting certificate audit trail:', error);
            return {
                events: [],
                error: error instanceof Error ? error.message : 'Unknown error'
            };
        }
    }
    /**
     * Get audit trail for a specific actor
     */
    async getActorAuditTrail(request) {
        try {
            const events = await this.auditService.getActorAuditTrail(request.actor);
            return { events };
        }
        catch (error) {
            console.error('[AuditPlan] Error getting actor audit trail:', error);
            return {
                events: [],
                error: error instanceof Error ? error.message : 'Unknown error'
            };
        }
    }
    /**
     * Prune old audit events
     */
    async pruneOldEvents(request) {
        try {
            await this.auditService.pruneOldEvents(request.daysToKeep);
            return { success: true };
        }
        catch (error) {
            console.error('[AuditPlan] Error pruning old events:', error);
            return {
                success: false,
                error: error instanceof Error ? error.message : 'Unknown error'
            };
        }
    }
}
//# sourceMappingURL=AuditPlan.js.map