/**
 * TrustPlan - RPC-style interface for trust operations
 *
 * Provides transport-agnostic access to trust functionality for:
 * - Electron IPC plans
 * - Web Workers
 * - React Native bridges
 */
import type { SHA256IdHash } from '@refinio/one.core/lib/util/type-checks.js';
import type { Person } from '@refinio/one.core/lib/recipes.js';
import type { TrustModel } from '../models/TrustModel.js';
import type { DeviceCredentials, TrustStatus, TrustEntry, TrustEvaluation, TrustLevel, TrustChain } from '../types/trust-types.js';
/**
 * Request/Response types for RPC-style communication
 */
export interface SetTrustStatusRequest {
    deviceId: SHA256IdHash<Person>;
    publicKey: string;
    status: TrustStatus;
}
export interface SetTrustStatusResponse {
    success: boolean;
    error?: string;
}
export interface GetTrustStatusRequest {
    deviceId: SHA256IdHash<Person>;
}
export interface GetTrustStatusResponse {
    status?: TrustStatus;
    error?: string;
}
export interface GetTrustedDevicesResponse {
    devices: TrustEntry[];
    error?: string;
}
export interface VerifyDeviceKeyRequest {
    deviceId: SHA256IdHash<Person>;
    publicKey: string;
}
export interface VerifyDeviceKeyResponse {
    isValid: boolean;
    error?: string;
}
export interface EvaluateTrustRequest {
    personId: SHA256IdHash<Person>;
    context?: 'general' | 'file-transfer' | 'communication';
}
export interface EvaluateTrustResponse {
    evaluation?: TrustEvaluation;
    error?: string;
}
export interface GetDeviceCredentialsResponse {
    credentials?: DeviceCredentials;
    error?: string;
}
export interface SetTrustLevelRequest {
    personId: SHA256IdHash<Person>;
    trustLevel: TrustLevel;
    establishedBy?: SHA256IdHash<Person>;
    reason?: string;
}
export interface SetTrustLevelResponse {
    success: boolean;
    error?: string;
}
export interface GetTrustLevelRequest {
    personId: SHA256IdHash<Person>;
}
export interface GetTrustLevelResponse {
    trustLevel?: TrustLevel;
    error?: string;
}
export interface GetTrustChainRequest {
    personId: SHA256IdHash<Person>;
    maxDepth?: number;
}
export interface GetTrustChainResponse {
    chain?: TrustChain;
    error?: string;
}
/**
 * TrustPlan - Transport-agnostic trust operations
 *
 * Follows dependency injection pattern:
 * - Platforms create plan: new TrustPlan(trustModel)
 * - Plan methods are pure business logic
 * - No platform-specific code
 */
export declare class TrustPlan {
    private trustModel;
    constructor(trustModel: TrustModel);
    /**
     * Set trust status for a device/person
     */
    setTrustStatus(request: SetTrustStatusRequest): Promise<SetTrustStatusResponse>;
    /**
     * Get trust status for a device/person
     */
    getTrustStatus(request: GetTrustStatusRequest): Promise<GetTrustStatusResponse>;
    /**
     * Get all trusted devices
     */
    getTrustedDevices(): Promise<GetTrustedDevicesResponse>;
    /**
     * Verify a device's public key
     */
    verifyDeviceKey(request: VerifyDeviceKeyRequest): Promise<VerifyDeviceKeyResponse>;
    /**
     * Evaluate trust level for a person
     */
    evaluateTrust(request: EvaluateTrustRequest): Promise<EvaluateTrustResponse>;
    /**
     * Get device credentials
     */
    getDeviceCredentials(): Promise<GetDeviceCredentialsResponse>;
    /**
     * Set trust level for a person
     * Used when accepting invitations, manual verification, etc.
     */
    setTrustLevel(request: SetTrustLevelRequest): Promise<SetTrustLevelResponse>;
    /**
     * Get trust level for a person
     */
    getTrustLevel(request: GetTrustLevelRequest): Promise<GetTrustLevelResponse>;
    /**
     * Get trust chain for a person (for chain of trust visualization)
     */
    getTrustChain(request: GetTrustChainRequest): Promise<GetTrustChainResponse>;
}
//# sourceMappingURL=TrustPlan.d.ts.map