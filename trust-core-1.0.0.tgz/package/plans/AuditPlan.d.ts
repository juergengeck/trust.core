/**
 * AuditPlan - Audit Trail Plan
 *
 * RPC-style plan for audit trail operations.
 * Provides transport-agnostic interface for audit event tracking and queries.
 */
import type { SHA256IdHash } from '@refinio/one.core/lib/util/type-checks.js';
import type { Person } from '@refinio/one.core/lib/recipes.js';
import type { AuditTrailService, AuditEvent, AuditEventType, AuditQueryOptions } from '../services/AuditTrailService.js';
/**
 * Request/Response types for AuditPlan
 */
export interface RecordEventRequest {
    eventType: AuditEventType;
    actor: SHA256IdHash<Person>;
    subject?: SHA256IdHash<Person> | string;
    certificateId?: string;
    certificateHash?: string;
    certificateVersion?: number;
    reason?: string;
    metadata?: Record<string, any>;
    success: boolean;
    error?: string;
}
export interface RecordEventResponse {
    success: boolean;
    error?: string;
}
export interface QueryEventsRequest {
    options?: AuditQueryOptions;
}
export interface QueryEventsResponse {
    events: AuditEvent[];
    error?: string;
}
export interface GetCertificateAuditTrailRequest {
    certificateId: string;
}
export interface GetCertificateAuditTrailResponse {
    events: AuditEvent[];
    error?: string;
}
export interface GetActorAuditTrailRequest {
    actor: SHA256IdHash<Person>;
}
export interface GetActorAuditTrailResponse {
    events: AuditEvent[];
    error?: string;
}
export interface PruneOldEventsRequest {
    daysToKeep?: number;
}
export interface PruneOldEventsResponse {
    success: boolean;
    error?: string;
}
/**
 * AuditPlan
 *
 * Transport-agnostic audit trail operations.
 * Designed for use with IPC, HTTP, or other RPC mechanisms.
 */
export declare class AuditPlan {
    private auditService;
    constructor(auditService: AuditTrailService);
    /**
     * Record an audit event
     */
    recordEvent(request: RecordEventRequest): Promise<RecordEventResponse>;
    /**
     * Query audit events
     */
    queryEvents(request: QueryEventsRequest): Promise<QueryEventsResponse>;
    /**
     * Get audit trail for a specific certificate
     */
    getCertificateAuditTrail(request: GetCertificateAuditTrailRequest): Promise<GetCertificateAuditTrailResponse>;
    /**
     * Get audit trail for a specific actor
     */
    getActorAuditTrail(request: GetActorAuditTrailRequest): Promise<GetActorAuditTrailResponse>;
    /**
     * Prune old audit events
     */
    pruneOldEvents(request: PruneOldEventsRequest): Promise<PruneOldEventsResponse>;
}
//# sourceMappingURL=AuditPlan.d.ts.map