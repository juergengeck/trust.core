/**
 * VCPropagationPlan - VC Propagation Plan
 *
 * RPC-style plan for VC propagation operations.
 * Provides transport-agnostic interface for managing certificate propagation.
 */
/**
 * VCPropagationPlan
 *
 * Transport-agnostic VC propagation operations.
 * Designed for use with IPC, HTTP, or other RPC mechanisms.
 */
export class VCPropagationPlan {
    propagationService;
    constructor(propagationService) {
        this.propagationService = propagationService;
    }
    /**
     * Queue a certificate for propagation
     */
    async queueForPropagation(request) {
        try {
            await this.propagationService.queueForPropagation(request.certificateId, request.certificateHash, request.options);
            return { success: true };
        }
        catch (error) {
            console.error('[VCPropagationPlan] Error queueing for propagation:', error);
            return {
                success: false,
                error: error instanceof Error ? error.message : 'Unknown error'
            };
        }
    }
    /**
     * Get propagation status for a certificate
     */
    async getPropagationStatus(request) {
        try {
            const record = this.propagationService.getPropagationStatus(request.certificateId);
            return { record };
        }
        catch (error) {
            console.error('[VCPropagationPlan] Error getting propagation status:', error);
            return {
                record: null,
                error: error instanceof Error ? error.message : 'Unknown error'
            };
        }
    }
    /**
     * Retry failed propagations
     */
    async retryFailed() {
        try {
            await this.propagationService.retryFailed();
            return { success: true };
        }
        catch (error) {
            console.error('[VCPropagationPlan] Error retrying failed propagations:', error);
            return {
                success: false,
                error: error instanceof Error ? error.message : 'Unknown error'
            };
        }
    }
}
//# sourceMappingURL=VCPropagationPlan.js.map