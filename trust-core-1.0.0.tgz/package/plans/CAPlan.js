/**
 * CAPlan - Certificate Authority Plan
 *
 * RPC-style plan for certificate authority operations.
 * Provides transport-agnostic interface for certificate management.
 * Integrates with StoryFactory for journal/audit trail visibility.
 */
import { VCBridge } from '../models/VCBridge.js';
/**
 * CAPlan
 *
 * Transport-agnostic certificate authority operations.
 * Designed for use with IPC, HTTP, or other RPC mechanisms.
 * Integrates with StoryFactory for journal/audit trail visibility.
 */
export class CAPlan {
    static PLAN_ID = 'CAPlan';
    static PLAN_NAME = 'Certificate Authority Plan';
    static PLAN_DESCRIPTION = 'Manages certificate issuance, extension, and revocation';
    static PLAN_DOMAIN = 'trust';
    caModel;
    storyFactory = null;
    planIdHash = null;
    constructor(caModel) {
        this.caModel = caModel;
    }
    /**
     * Set the StoryFactory and register the Plan ONE object.
     */
    async setStoryFactory(factory) {
        this.storyFactory = factory;
        this.planIdHash = await factory.registerPlan({
            id: CAPlan.PLAN_ID,
            name: CAPlan.PLAN_NAME,
            description: CAPlan.PLAN_DESCRIPTION,
            domain: CAPlan.PLAN_DOMAIN,
            demandPatterns: [
                { keywords: ['certificate', 'trust', 'identity'] },
                { keywords: ['device', 'keys', 'attestation'] }
            ],
            supplyPatterns: [
                { keywords: ['certificate', 'issued', 'valid'] },
                { keywords: ['trust', 'verified', 'attested'] }
            ]
        });
        console.log(`[CAPlan] Registered Plan with hash: ${this.planIdHash.substring(0, 8)}...`);
    }
    /**
     * Get the Plan's real SHA256IdHash (must be initialized first)
     */
    getPlanIdHash() {
        if (!this.planIdHash) {
            throw new Error('[CAPlan] Plan not registered - call setStoryFactory first');
        }
        return this.planIdHash;
    }
    /**
     * Issue a new certificate
     */
    async issueCertificate(request) {
        const options = {
            certificateType: request.certificateType,
            subject: request.subject,
            subjectPublicKey: request.subjectPublicKey,
            validityDays: request.validityDays,
            chainDepth: request.chainDepth,
            issuedBy: request.issuedBy,
            claims: request.claims
        };
        // If no StoryFactory, fall back to direct operation (no Assembly)
        if (!this.storyFactory) {
            const certificateHash = await this.caModel.issueCertificate(options);
            const certificate = await this.caModel.getCertificate(options.certificateType + ':' + options.subject);
            return {
                certificateHash,
                certificateId: certificate?.id || ''
            };
        }
        // Story metadata for journal visibility
        const subjectStr = String(request.subject).substring(0, 8);
        const metadata = {
            title: `Certificate "${request.certificateType}" issued for ${subjectStr}`,
            planId: this.getPlanIdHash(),
            planTypeName: CAPlan.PLAN_ID,
            owner: request.subject,
            instanceVersion: `instance-${Date.now()}`
        };
        // Use wrapExecution to create Story atomically
        const result = await this.storyFactory.wrapExecution(metadata, async () => {
            const certificateHash = await this.caModel.issueCertificate(options);
            const certificate = await this.caModel.getCertificate(options.certificateType + ':' + options.subject);
            return {
                result: {
                    certificateHash,
                    certificateId: certificate?.id || ''
                },
                productHash: certificateHash
            };
        });
        console.log(`[CAPlan] ✅ Issued certificate with Story: ${result.storyId?.toString().substring(0, 8)}...`);
        return {
            result: result.result,
            storyId: result.storyId,
            assemblyId: result.assemblyId
        };
    }
    /**
     * Issue a device trust certificate
     */
    async issueDeviceCertificate(request) {
        // If no StoryFactory, fall back to direct operation
        if (!this.storyFactory) {
            const certificateHash = await this.caModel.issueDeviceCertificate(request.subject, request.subjectPublicKey, {
                trustLevel: request.trustLevel,
                permissions: request.permissions,
                validityDays: request.validityDays,
                trustReason: request.trustReason,
                verificationMethod: request.verificationMethod
            });
            const certificate = await this.caModel.getCertificate(`cert:device:${request.subject}`);
            return {
                certificateHash,
                certificateId: certificate?.id || ''
            };
        }
        // Story metadata for journal visibility
        const subjectStr = request.subject.substring(0, 8);
        const trustLevel = request.trustLevel || 'full';
        const metadata = {
            title: `Device certificate issued (${trustLevel}) for ${subjectStr}`,
            planId: this.getPlanIdHash(),
            planTypeName: CAPlan.PLAN_ID,
            owner: request.subject,
            instanceVersion: `instance-${Date.now()}`
        };
        const result = await this.storyFactory.wrapExecution(metadata, async () => {
            const certificateHash = await this.caModel.issueDeviceCertificate(request.subject, request.subjectPublicKey, {
                trustLevel: request.trustLevel,
                permissions: request.permissions,
                validityDays: request.validityDays,
                trustReason: request.trustReason,
                verificationMethod: request.verificationMethod
            });
            const certificate = await this.caModel.getCertificate(`cert:device:${request.subject}`);
            return {
                result: {
                    certificateHash,
                    certificateId: certificate?.id || ''
                },
                productHash: certificateHash
            };
        });
        console.log(`[CAPlan] ✅ Issued device certificate with Story: ${result.storyId?.toString().substring(0, 8)}...`);
        return {
            result: result.result,
            storyId: result.storyId,
            assemblyId: result.assemblyId
        };
    }
    /**
     * Extend a certificate's validity
     */
    async extendCertificate(request) {
        // If no StoryFactory, fall back to direct operation
        if (!this.storyFactory) {
            const certificateHash = await this.caModel.extendCertificate({
                certificateId: request.certificateId,
                additionalDays: request.additionalDays
            });
            const certificate = await this.caModel.getCertificate(request.certificateId);
            return {
                certificateHash,
                newValidUntil: certificate?.validUntil || 0
            };
        }
        // Story metadata for journal visibility
        const certIdShort = request.certificateId.substring(0, 16);
        const metadata = {
            title: `Certificate extended by ${request.additionalDays} days: ${certIdShort}`,
            planId: this.getPlanIdHash(),
            planTypeName: CAPlan.PLAN_ID,
            owner: undefined, // Certificate owner not available from certificateId
            instanceVersion: `instance-${Date.now()}`
        };
        const result = await this.storyFactory.wrapExecution(metadata, async () => {
            const certificateHash = await this.caModel.extendCertificate({
                certificateId: request.certificateId,
                additionalDays: request.additionalDays
            });
            const certificate = await this.caModel.getCertificate(request.certificateId);
            return {
                result: {
                    certificateHash,
                    newValidUntil: certificate?.validUntil || 0
                },
                productHash: certificateHash
            };
        });
        console.log(`[CAPlan] ✅ Extended certificate with Story: ${result.storyId?.toString().substring(0, 8)}...`);
        return {
            result: result.result,
            storyId: result.storyId,
            assemblyId: result.assemblyId
        };
    }
    /**
     * Revoke a certificate
     */
    async revokeCertificate(request) {
        // If no StoryFactory, fall back to direct operation
        if (!this.storyFactory) {
            const certificateHash = await this.caModel.revokeCertificate({
                certificateId: request.certificateId,
                reason: request.reason
            });
            return {
                certificateHash,
                revokedAt: Date.now()
            };
        }
        // Story metadata for journal visibility
        const certIdShort = request.certificateId.substring(0, 16);
        const reasonText = request.reason ? `: ${request.reason}` : '';
        const metadata = {
            title: `Certificate revoked: ${certIdShort}${reasonText}`,
            planId: this.getPlanIdHash(),
            planTypeName: CAPlan.PLAN_ID,
            owner: undefined, // Certificate owner not available from certificateId
            instanceVersion: `instance-${Date.now()}`
        };
        const result = await this.storyFactory.wrapExecution(metadata, async () => {
            const certificateHash = await this.caModel.revokeCertificate({
                certificateId: request.certificateId,
                reason: request.reason
            });
            return {
                result: {
                    certificateHash,
                    revokedAt: Date.now()
                },
                productHash: certificateHash
            };
        });
        console.log(`[CAPlan] ✅ Revoked certificate with Story: ${result.storyId?.toString().substring(0, 8)}...`);
        return {
            result: result.result,
            storyId: result.storyId,
            assemblyId: result.assemblyId
        };
    }
    /**
     * Get a certificate by ID
     */
    async getCertificate(request) {
        const certificate = await this.caModel.getCertificate(request.certificateId);
        return {
            certificate
        };
    }
    /**
     * Get certificate history (all versions)
     */
    async getCertificateHistory(request) {
        const versions = await this.caModel.getCertificateHistory(request.certificateId);
        return {
            versions
        };
    }
    /**
     * Verify certificate validity
     */
    async verifyCertificate(request) {
        const result = await this.caModel.verifyCertificate(request.certificate);
        return result;
    }
    /**
     * Export certificate as Verifiable Credential
     */
    async exportAsVC(request) {
        const certificate = await this.caModel.getCertificate(request.certificateId);
        if (!certificate) {
            throw new Error(`Certificate not found: ${request.certificateId}`);
        }
        const verifiableCredential = VCBridge.certificateToVC(certificate);
        const jsonLD = VCBridge.exportAsJsonLD(certificate);
        return {
            verifiableCredential,
            jsonLD
        };
    }
    /**
     * Import Verifiable Credential as Certificate
     */
    async importVC(request) {
        const vc = VCBridge.importFromJsonLD(request.jsonLD);
        const certificate = VCBridge.vcToCertificate(vc);
        // Store the certificate
        const oneCore = this.caModel.oneCore; // Access private field
        const certificateHash = await oneCore.storeVersionedObject(certificate);
        return {
            certificateHash,
            certificateId: certificate.id
        };
    }
    /**
     * Get root certificate for this CA
     */
    async getRootCertificate() {
        return this.caModel.getRootCertificate();
    }
}
//# sourceMappingURL=CAPlan.js.map