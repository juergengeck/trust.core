/**
 * SubscriptionPlan - Subscription Management Plan
 *
 * RPC-style plan for subscription certificate operations.
 * Provides transport-agnostic interface for subscription management.
 */
import type { SHA256Hash, SHA256IdHash } from '@refinio/one.core/lib/util/type-checks.js';
import type { Person } from '@refinio/one.core/lib/recipes.js';
import type { SubscriptionTier } from '../recipes/SubscriptionCertificate.js';
import type { Certificate } from '../recipes/Certificate.js';
import { CAModel } from '../models/CAModel.js';
/**
 * Request/Response types for SubscriptionPlan
 */
export interface IssueSubscriptionRequest {
    userId: SHA256IdHash<Person>;
    userPublicKey: string;
    tier: SubscriptionTier;
    priceEur: number;
    paymentId: string;
    depositAmount: number;
    autoRenew?: boolean;
}
export interface IssueSubscriptionResponse {
    certificateHash: SHA256Hash<Certificate>;
    certificateId: string;
    validUntil: number;
}
export interface GetSubscriptionRequest {
    userId: SHA256IdHash<Person>;
}
export interface GetSubscriptionResponse {
    subscription: Certificate | null;
    isActive: boolean;
    daysRemaining: number;
}
export interface RenewSubscriptionRequest {
    userId: SHA256IdHash<Person>;
    additionalDays: number;
    paymentId: string;
    depositAmount: number;
}
export interface RenewSubscriptionResponse {
    certificateHash: SHA256Hash<Certificate>;
    newValidUntil: number;
}
export interface CancelSubscriptionRequest {
    userId: SHA256IdHash<Person>;
    reason?: string;
}
export interface CancelSubscriptionResponse {
    success: boolean;
    cancelledAt: number;
}
export interface CheckSubscriptionStatusRequest {
    userId: SHA256IdHash<Person>;
}
export interface CheckSubscriptionStatusResponse {
    isActive: boolean;
    tier: SubscriptionTier;
    validUntil: number;
    daysRemaining: number;
    features: string[];
}
/**
 * SubscriptionPlan
 *
 * Transport-agnostic subscription management operations.
 * Uses CAModel for certificate operations.
 */
export declare class SubscriptionPlan {
    private caModel;
    constructor(caModel: CAModel);
    /**
     * Issue a new subscription certificate
     */
    issueSubscription(request: IssueSubscriptionRequest): Promise<IssueSubscriptionResponse>;
    /**
     * Get current subscription for user
     */
    getSubscription(request: GetSubscriptionRequest): Promise<GetSubscriptionResponse>;
    /**
     * Renew subscription (extend validity)
     */
    renewSubscription(request: RenewSubscriptionRequest): Promise<RenewSubscriptionResponse>;
    /**
     * Cancel subscription (revoke certificate)
     */
    cancelSubscription(request: CancelSubscriptionRequest): Promise<CancelSubscriptionResponse>;
    /**
     * Check subscription status
     */
    checkSubscriptionStatus(request: CheckSubscriptionStatusRequest): Promise<CheckSubscriptionStatusResponse>;
    /**
     * Get features for subscription tier
     */
    private getFeaturesForTier;
}
//# sourceMappingURL=SubscriptionPlan.d.ts.map