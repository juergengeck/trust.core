/**
 * CAPlan - Certificate Authority Plan
 *
 * RPC-style plan for certificate authority operations.
 * Provides transport-agnostic interface for certificate management.
 * Integrates with StoryFactory for journal/audit trail visibility.
 */
import type { SHA256Hash, SHA256IdHash } from '@refinio/one.core/lib/util/type-checks.js';
import type { Person } from '@refinio/one.core/lib/recipes.js';
import type { Certificate, CertificateType } from '../recipes/Certificate.js';
import type { TrustKeysCertificate } from '../recipes/TrustKeysCertificate.js';
import type { VerifiableCredential } from '../recipes/VerifiableCredential.js';
import type { StoryFactory, ExecutionResult, Plan } from '@refinio/api/plan-system';
import { CAModel } from '../models/CAModel.js';
/**
 * Request/Response types for CAPlan
 */
export interface IssueCertificateRequest {
    certificateType: CertificateType;
    subject: SHA256IdHash<Person> | string;
    subjectPublicKey: string;
    validityDays?: number;
    chainDepth?: number;
    issuedBy?: SHA256Hash<Certificate>;
    claims?: Record<string, any>;
}
export interface IssueCertificateResponse {
    certificateHash: SHA256Hash<Certificate>;
    certificateId: string;
}
export interface IssueDeviceCertificateRequest {
    subject: SHA256IdHash<Person>;
    subjectPublicKey: string;
    trustLevel?: 'full' | 'limited' | 'temporary';
    permissions?: Record<string, boolean>;
    validityDays?: number;
    trustReason?: string;
    verificationMethod?: string;
}
export interface IssueDeviceCertificateResponse {
    certificateHash: SHA256Hash<TrustKeysCertificate>;
    certificateId: string;
}
export interface ExtendCertificateRequest {
    certificateId: string;
    additionalDays: number;
}
export interface ExtendCertificateResponse {
    certificateHash: SHA256Hash<Certificate>;
    newValidUntil: number;
}
export interface RevokeCertificateRequest {
    certificateId: string;
    reason?: string;
}
export interface RevokeCertificateResponse {
    certificateHash: SHA256Hash<Certificate>;
    revokedAt: number;
}
export interface GetCertificateRequest {
    certificateId: string;
}
export interface GetCertificateResponse {
    certificate: Certificate | null;
}
export interface GetCertificateHistoryRequest {
    certificateId: string;
}
export interface GetCertificateHistoryResponse {
    versions: Certificate[];
}
export interface VerifyCertificateRequest {
    certificate: Certificate;
}
export interface VerifyCertificateResponse {
    valid: boolean;
    reason?: string;
}
export interface ExportAsVCRequest {
    certificateId: string;
}
export interface ExportAsVCResponse {
    verifiableCredential: VerifiableCredential;
    jsonLD: string;
}
export interface ImportVCRequest {
    jsonLD: string;
}
export interface ImportVCResponse {
    certificateHash: SHA256Hash<Certificate>;
    certificateId: string;
}
/**
 * CAPlan
 *
 * Transport-agnostic certificate authority operations.
 * Designed for use with IPC, HTTP, or other RPC mechanisms.
 * Integrates with StoryFactory for journal/audit trail visibility.
 */
export declare class CAPlan {
    static readonly PLAN_ID = "CAPlan";
    static readonly PLAN_NAME = "Certificate Authority Plan";
    static readonly PLAN_DESCRIPTION = "Manages certificate issuance, extension, and revocation";
    static readonly PLAN_DOMAIN = "trust";
    private caModel;
    private storyFactory;
    private planIdHash;
    constructor(caModel: CAModel);
    /**
     * Set the StoryFactory and register the Plan ONE object.
     */
    setStoryFactory(factory: StoryFactory): Promise<void>;
    /**
     * Get the Plan's real SHA256IdHash (must be initialized first)
     */
    getPlanIdHash(): SHA256IdHash<Plan>;
    /**
     * Issue a new certificate
     */
    issueCertificate(request: IssueCertificateRequest): Promise<IssueCertificateResponse | ExecutionResult<IssueCertificateResponse>>;
    /**
     * Issue a device trust certificate
     */
    issueDeviceCertificate(request: IssueDeviceCertificateRequest): Promise<IssueDeviceCertificateResponse | ExecutionResult<IssueDeviceCertificateResponse>>;
    /**
     * Extend a certificate's validity
     */
    extendCertificate(request: ExtendCertificateRequest): Promise<ExtendCertificateResponse | ExecutionResult<ExtendCertificateResponse>>;
    /**
     * Revoke a certificate
     */
    revokeCertificate(request: RevokeCertificateRequest): Promise<RevokeCertificateResponse | ExecutionResult<RevokeCertificateResponse>>;
    /**
     * Get a certificate by ID
     */
    getCertificate(request: GetCertificateRequest): Promise<GetCertificateResponse>;
    /**
     * Get certificate history (all versions)
     */
    getCertificateHistory(request: GetCertificateHistoryRequest): Promise<GetCertificateHistoryResponse>;
    /**
     * Verify certificate validity
     */
    verifyCertificate(request: VerifyCertificateRequest): Promise<VerifyCertificateResponse>;
    /**
     * Export certificate as Verifiable Credential
     */
    exportAsVC(request: ExportAsVCRequest): Promise<ExportAsVCResponse>;
    /**
     * Import Verifiable Credential as Certificate
     */
    importVC(request: ImportVCRequest): Promise<ImportVCResponse>;
    /**
     * Get root certificate for this CA
     */
    getRootCertificate(): Promise<Certificate | null>;
}
//# sourceMappingURL=CAPlan.d.ts.map