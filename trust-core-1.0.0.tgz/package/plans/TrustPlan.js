/**
 * TrustPlan - RPC-style interface for trust operations
 *
 * Provides transport-agnostic access to trust functionality for:
 * - Electron IPC plans
 * - Web Workers
 * - React Native bridges
 */
/**
 * TrustPlan - Transport-agnostic trust operations
 *
 * Follows dependency injection pattern:
 * - Platforms create plan: new TrustPlan(trustModel)
 * - Plan methods are pure business logic
 * - No platform-specific code
 */
export class TrustPlan {
    trustModel;
    constructor(trustModel) {
        this.trustModel = trustModel;
    }
    /**
     * Set trust status for a device/person
     */
    async setTrustStatus(request) {
        try {
            await this.trustModel.setTrustStatus(request.deviceId, request.publicKey, request.status);
            return { success: true };
        }
        catch (error) {
            console.error('[TrustPlan] Error setting trust status:', error);
            return {
                success: false,
                error: error instanceof Error ? error.message : 'Unknown error'
            };
        }
    }
    /**
     * Get trust status for a device/person
     */
    async getTrustStatus(request) {
        try {
            const status = await this.trustModel.getTrustStatus(request.deviceId);
            return { status };
        }
        catch (error) {
            console.error('[TrustPlan] Error getting trust status:', error);
            return {
                error: error instanceof Error ? error.message : 'Unknown error'
            };
        }
    }
    /**
     * Get all trusted devices
     */
    async getTrustedDevices() {
        try {
            const devices = await this.trustModel.getTrustedDevices();
            return { devices };
        }
        catch (error) {
            console.error('[TrustPlan] Error getting trusted devices:', error);
            return {
                devices: [],
                error: error instanceof Error ? error.message : 'Unknown error'
            };
        }
    }
    /**
     * Verify a device's public key
     */
    async verifyDeviceKey(request) {
        try {
            const isValid = await this.trustModel.verifyDeviceKey(request.deviceId, request.publicKey);
            return { isValid };
        }
        catch (error) {
            console.error('[TrustPlan] Error verifying device key:', error);
            return {
                isValid: false,
                error: error instanceof Error ? error.message : 'Unknown error'
            };
        }
    }
    /**
     * Evaluate trust level for a person
     */
    async evaluateTrust(request) {
        try {
            const evaluation = await this.trustModel.evaluateTrust(request.personId, request.context || 'general');
            return { evaluation };
        }
        catch (error) {
            console.error('[TrustPlan] Error evaluating trust:', error);
            return {
                error: error instanceof Error ? error.message : 'Unknown error'
            };
        }
    }
    /**
     * Get device credentials
     */
    async getDeviceCredentials() {
        try {
            const credentials = this.trustModel.getDeviceCredentials();
            return { credentials };
        }
        catch (error) {
            console.error('[TrustPlan] Error getting device credentials:', error);
            return {
                error: error instanceof Error ? error.message : 'Unknown error'
            };
        }
    }
    /**
     * Set trust level for a person
     * Used when accepting invitations, manual verification, etc.
     */
    async setTrustLevel(request) {
        try {
            await this.trustModel.setTrustLevel(request.personId, request.trustLevel, request.establishedBy, request.reason);
            return { success: true };
        }
        catch (error) {
            console.error('[TrustPlan] Error setting trust level:', error);
            return {
                success: false,
                error: error instanceof Error ? error.message : 'Unknown error'
            };
        }
    }
    /**
     * Get trust level for a person
     */
    async getTrustLevel(request) {
        try {
            const trustLevel = await this.trustModel.getTrustLevel(request.personId);
            return { trustLevel };
        }
        catch (error) {
            console.error('[TrustPlan] Error getting trust level:', error);
            return {
                error: error instanceof Error ? error.message : 'Unknown error'
            };
        }
    }
    /**
     * Get trust chain for a person (for chain of trust visualization)
     */
    async getTrustChain(request) {
        try {
            const chain = await this.trustModel.getTrustChain(request.personId, request.maxDepth || 3);
            return { chain };
        }
        catch (error) {
            console.error('[TrustPlan] Error getting trust chain:', error);
            return {
                error: error instanceof Error ? error.message : 'Unknown error'
            };
        }
    }
}
//# sourceMappingURL=TrustPlan.js.map