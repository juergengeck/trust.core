/**
 * VCPropagationPlan - VC Propagation Plan
 *
 * RPC-style plan for VC propagation operations.
 * Provides transport-agnostic interface for managing certificate propagation.
 */
import type { SHA256Hash } from '@refinio/one.core/lib/util/type-checks.js';
import type { Certificate } from '../recipes/Certificate.js';
import type { VCPropagationService, PropagationRecord } from '../services/VCPropagationService.js';
/**
 * Request/Response types for VCPropagationPlan
 */
export interface QueueForPropagationRequest {
    certificateId: string;
    certificateHash: SHA256Hash<Certificate>;
    options?: {
        internalOnly?: boolean;
        externalUrl?: string;
    };
}
export interface QueueForPropagationResponse {
    success: boolean;
    error?: string;
}
export interface GetPropagationStatusRequest {
    certificateId: string;
}
export interface GetPropagationStatusResponse {
    record: PropagationRecord | null;
    error?: string;
}
export interface RetryFailedResponse {
    success: boolean;
    error?: string;
}
/**
 * VCPropagationPlan
 *
 * Transport-agnostic VC propagation operations.
 * Designed for use with IPC, HTTP, or other RPC mechanisms.
 */
export declare class VCPropagationPlan {
    private propagationService;
    constructor(propagationService: VCPropagationService);
    /**
     * Queue a certificate for propagation
     */
    queueForPropagation(request: QueueForPropagationRequest): Promise<QueueForPropagationResponse>;
    /**
     * Get propagation status for a certificate
     */
    getPropagationStatus(request: GetPropagationStatusRequest): Promise<GetPropagationStatusResponse>;
    /**
     * Retry failed propagations
     */
    retryFailed(): Promise<RetryFailedResponse>;
}
//# sourceMappingURL=VCPropagationPlan.d.ts.map