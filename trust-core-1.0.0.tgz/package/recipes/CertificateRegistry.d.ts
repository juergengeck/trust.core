/**
 * CertificateRegistry Recipe
 *
 * ONE.core recipe for storing certificate registries.
 * Certificates are versioned so they can be revoked by creating new versions
 * with updated validity periods. The registry itself is versioned for auditability.
 */
import type { Recipe, OneObjectTypeNames } from '@refinio/one.core/lib/recipes.js';
import type { SHA256Hash } from '@refinio/one.core/lib/util/type-checks.js';
/**
 * CertificateRegistry - Versioned object storing certificates
 *
 * This is stored as a ONE.core versioned object and can be:
 * - Updated to add/revoke certificates
 * - Versioned for complete audit trail
 * - Shared via CHUM for synchronization
 *
 * The registry uses an ID property to enable versioning - each update
 * creates a new version while maintaining the history for auditing.
 */
export interface CertificateRegistry {
    $type$: 'CertificateRegistry';
    id: string;
    certificates: SHA256Hash<any>[];
}
/**
 * ONE.core recipe definition for CertificateRegistry
 */
export declare const CertificateRegistryRecipe: Recipe;
/**
 * Reverse map for querying CertificateRegistry objects
 */
export declare const CertificateRegistryReverseMap: [OneObjectTypeNames, Set<string>];
declare module '@OneObjectInterfaces' {
    interface OneIdObjectInterfaces {
        CertificateRegistry: Pick<CertificateRegistry, 'id' | '$type$'>;
    }
    interface OneVersionedObjectInterfaces {
        CertificateRegistry: CertificateRegistry;
    }
}
//# sourceMappingURL=CertificateRegistry.d.ts.map