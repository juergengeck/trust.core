/**
 * SubscriptionBalance Recipe
 *
 * Tracks user's subscription balance and deposit history.
 * Stored as a versioned object keyed by user's Person ID.
 */
import type { Recipe, Person } from '@refinio/one.core/lib/recipes.js';
import type { SHA256IdHash } from '@refinio/one.core/lib/util/type-checks.js';
/**
 * SubscriptionBalance Object
 *
 * ONE.core versioned object that stores subscription balance information.
 */
export interface SubscriptionBalance {
    $type$: 'SubscriptionBalance';
    userId: SHA256IdHash<Person>;
    balance: number;
    totalDeposited: number;
    lastUpdated: number;
    version: number;
}
/**
 * Extend ONE.core's type system
 */
declare module '@OneObjectInterfaces' {
    interface OneVersionedObjectInterfaces {
        SubscriptionBalance: SubscriptionBalance;
    }
}
/**
 * SubscriptionBalance Recipe Definition
 */
export declare const SubscriptionBalanceRecipe: Recipe;
/**
 * Reverse map for SubscriptionBalance (for querying by userId)
 */
export declare const SubscriptionBalanceReverseMap: [string, Set<string>];
export default SubscriptionBalanceRecipe;
//# sourceMappingURL=SubscriptionBalance.d.ts.map