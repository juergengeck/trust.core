/**
 * TrustRelationship Recipe
 *
 * ONE.core recipe for storing trust relationships between devices/persons.
 * Integrates with ONE.models TrustedKeysManager and TrustKeysCertificate.
 */
import type { Recipe, OneObjectTypeNames, Person } from '@refinio/one.core/lib/recipes.js';
import type { SHA256Hash, SHA256IdHash } from '@refinio/one.core/lib/util/type-checks.js';
/**
 * Trust status values
 */
export type TrustStatus = 'trusted' | 'untrusted' | 'pending' | 'revoked';
/**
 * Trust level for app-to-app communication
 *
 * Levels:
 * - self: Trust assigned to own devices (highest trust)
 * - high: Manually verified contacts with strong authentication
 * - medium: Contacts added via invitation (default for accepted invites)
 * - low: Contacts with limited verification or indirect trust
 */
export type TrustLevel = 'self' | 'high' | 'medium' | 'low';
/**
 * TrustRelationship - Versioned object storing trust status for a person/device
 *
 * This is stored as a ONE.core versioned object and can be:
 * - Posted to channels for sharing trust attestations
 * - Signed to create TrustKeysCertificate
 * - Exported as Verifiable Credentials
 *
 * Relationships:
 * - issuer (implicit from signature) - Who declares this trust
 * - subject (peer) - Who is trusted
 * - status - Current trust level
 * - permissions - Granted capabilities
 */
export interface TrustRelationship {
    $type$: 'TrustRelationship';
    $version$: 'v1';
    id: string;
    peer: SHA256IdHash<Person>;
    peerPublicKey: string;
    status: TrustStatus;
    trustLevel?: TrustLevel;
    permissions?: {
        chat?: boolean;
        voiceCall?: boolean;
        videoCall?: boolean;
        fileRead?: boolean;
        fileWrite?: boolean;
        syncData?: boolean;
        seeOnlineStatus?: boolean;
        seeLocation?: boolean;
        seeActivity?: boolean;
        addToGroups?: boolean;
        shareContacts?: boolean;
    };
    establishedAt: string;
    lastVerified?: string;
    validUntil?: string;
    reason?: string;
    context?: string;
    verificationMethod?: string;
    verificationProof?: SHA256Hash<any>;
}
/**
 * ONE.core recipe definition for TrustRelationship
 */
export declare const TrustRelationshipRecipe: Recipe;
/**
 * Reverse map for querying TrustRelationship objects
 */
export declare const TrustRelationshipReverseMap: [OneObjectTypeNames, Set<string>];
declare module '@OneObjectInterfaces' {
    interface OneVersionedObjectInterfaces {
        TrustRelationship: TrustRelationship;
    }
}
//# sourceMappingURL=TrustRelationship.d.ts.map