/**
 * SubscriptionCertificate Recipe
 *
 * Certificate for identity subscription service on lama.one domains.
 *
 * IMPORTANT: This is NOT a software license - LAMA software is free and open.
 * This is an IDENTITY ATTESTATION service - a ROOT OF TRUST for 3rd parties.
 *
 * What you're buying: Time-bound proof that you own a specific identity
 * Example: claude@glue.one for 1€/month or 10€/year
 *
 * Use case: When interacting with unknown 3rd parties, share your certificate
 * to prove you control this identity on lama.one infrastructure.
 */
/**
 * ONE.core recipe definition for SubscriptionCertificate
 */
export const SubscriptionCertificateRecipe = {
    $type$: 'Recipe',
    name: 'SubscriptionCertificate',
    rule: [
        {
            itemprop: 'id',
            isId: true, // Makes this versioned with stable ID
            itemtype: { type: 'string' }
        },
        {
            itemprop: 'certificateType',
            itemtype: { type: 'string' }
        },
        {
            itemprop: 'status',
            itemtype: { type: 'string' }
        },
        {
            itemprop: 'subject',
            itemtype: { type: 'string' }
        },
        {
            itemprop: 'subjectPublicKey',
            itemtype: { type: 'string' }
        },
        {
            itemprop: 'issuer',
            itemtype: { type: 'referenceToId', allowedTypes: new Set(['Person']) }
        },
        {
            itemprop: 'issuerPublicKey',
            itemtype: { type: 'string' }
        },
        {
            itemprop: 'validFrom',
            itemtype: { type: 'number' }
        },
        {
            itemprop: 'validUntil',
            itemtype: { type: 'number' }
        },
        {
            itemprop: 'issuedBy',
            itemtype: { type: 'string' },
            optional: true
        },
        {
            itemprop: 'chainDepth',
            itemtype: { type: 'number' }
        },
        {
            itemprop: 'claims',
            itemtype: { type: 'stringifiable' } // JSON-serializable object
        },
        {
            itemprop: 'issuedAt',
            itemtype: { type: 'number' }
        },
        {
            itemprop: 'serialNumber',
            itemtype: { type: 'string' }
        },
        {
            itemprop: 'version',
            itemtype: { type: 'number' }
        },
        {
            itemprop: 'signature',
            itemtype: { type: 'string' },
            optional: true
        }
    ]
};
/**
 * Reverse map for querying SubscriptionCertificate objects
 */
export const SubscriptionCertificateReverseMap = [
    'SubscriptionCertificate',
    new Set(['id', 'subject', 'issuer'])
];
//# sourceMappingURL=SubscriptionCertificate.js.map