/**
 * TrustKeysCertificate Recipe
 *
 * Device trust certificate compatible with ONE.models TrustedKeysManager.
 * Extends Certificate with device-specific trust information.
 */
import type { Recipe, OneObjectTypeNames, Person } from '@refinio/one.core/lib/recipes.js';
import type { SHA256Hash, SHA256IdHash } from '@refinio/one.core/lib/util/type-checks.js';
/**
 * TrustKeysCertificate
 *
 * Device trust certificate that integrates with TrustedKeysManager.
 * Versioned object with time-bound validity and revocation support.
 *
 * This extends the base Certificate with device-specific fields:
 * - Device public key validation
 * - Trust relationship linkage
 * - Device-to-device trust chains
 */
export interface TrustKeysCertificate {
    $type$: 'TrustKeysCertificate';
    id: string;
    certificateType: 'device';
    status: 'valid' | 'expired' | 'revoked' | 'suspended';
    subject: SHA256IdHash<Person>;
    subjectPublicKey: string;
    deviceName?: string;
    issuer: SHA256IdHash<Person>;
    issuerPublicKey: string;
    validFrom: number;
    validUntil: number;
    issuedBy?: SHA256Hash<TrustKeysCertificate>;
    chainDepth: number;
    trustLevel: 'full' | 'limited' | 'temporary';
    trustReason?: string;
    verificationMethod?: string;
    permissions?: {
        chat?: boolean;
        voiceCall?: boolean;
        videoCall?: boolean;
        fileRead?: boolean;
        fileWrite?: boolean;
        syncData?: boolean;
        seeOnlineStatus?: boolean;
    };
    issuedAt: number;
    serialNumber: string;
    version: number;
    trustRelationship?: SHA256Hash<any>;
    signature?: string;
}
/**
 * ONE.core recipe definition for TrustKeysCertificate
 */
export declare const TrustKeysCertificateRecipe: Recipe;
/**
 * Reverse map for querying TrustKeysCertificate objects
 */
export declare const TrustKeysCertificateReverseMap: [OneObjectTypeNames, Set<string>];
declare module '@OneObjectInterfaces' {
    interface OneIdObjectInterfaces {
        TrustKeysCertificate: Pick<TrustKeysCertificate, 'id' | '$type$'>;
    }
    interface OneVersionedObjectInterfaces {
        TrustKeysCertificate: TrustKeysCertificate;
    }
}
//# sourceMappingURL=TrustKeysCertificate.d.ts.map