/**
 * ProfileResponse Recipe
 *
 * Sent when a user selects a discovered peer to initiate connection.
 * Contains an encrypted nonce that proves the responder can encrypt
 * to the challenger's public key.
 */
/**
 * ONE.core recipe definition for ProfileResponse
 */
export const ProfileResponseRecipe = {
    $type$: 'Recipe',
    name: 'ProfileResponse',
    rule: [
        {
            itemprop: 'responder',
            itemtype: { type: 'referenceToId', allowedTypes: new Set(['Person']) }
        },
        {
            itemprop: 'challenger',
            itemtype: { type: 'referenceToId', allowedTypes: new Set(['Person']) }
        },
        {
            itemprop: 'challengerProfile',
            itemtype: { type: 'referenceToObj', allowedTypes: new Set(['Profile']) }
        },
        {
            itemprop: 'encryptedNonce',
            itemtype: { type: 'string' }
        },
        {
            itemprop: 'created',
            itemtype: { type: 'number' }
        }
    ]
};
/**
 * Reverse map for querying ProfileResponse objects
 */
export const ProfileResponseReverseMap = [
    'ProfileResponse',
    new Set(['responder', 'challenger', 'challengerProfile'])
];
//# sourceMappingURL=ProfileResponse.js.map