/**
 * TrustKeysCertificate Recipe
 *
 * Device trust certificate compatible with ONE.models TrustedKeysManager.
 * Extends Certificate with device-specific trust information.
 */
/**
 * ONE.core recipe definition for TrustKeysCertificate
 */
export const TrustKeysCertificateRecipe = {
    $type$: 'Recipe',
    name: 'TrustKeysCertificate',
    rule: [
        {
            itemprop: 'id',
            isId: true, // Makes this versioned with stable ID
            itemtype: { type: 'string' }
        },
        {
            itemprop: 'certificateType',
            itemtype: { type: 'string' }
        },
        {
            itemprop: 'status',
            itemtype: { type: 'string' }
        },
        {
            itemprop: 'subject',
            itemtype: { type: 'referenceToId', allowedTypes: new Set(['Person']) }
        },
        {
            itemprop: 'subjectPublicKey',
            itemtype: { type: 'string' }
        },
        {
            itemprop: 'deviceName',
            itemtype: { type: 'string' },
            optional: true
        },
        {
            itemprop: 'issuer',
            itemtype: { type: 'referenceToId', allowedTypes: new Set(['Person']) }
        },
        {
            itemprop: 'issuerPublicKey',
            itemtype: { type: 'string' }
        },
        {
            itemprop: 'validFrom',
            itemtype: { type: 'number' }
        },
        {
            itemprop: 'validUntil',
            itemtype: { type: 'number' }
        },
        {
            itemprop: 'issuedBy',
            itemtype: { type: 'string' }, // Hash of parent certificate
            optional: true
        },
        {
            itemprop: 'chainDepth',
            itemtype: { type: 'number' }
        },
        {
            itemprop: 'trustLevel',
            itemtype: { type: 'string' }
        },
        {
            itemprop: 'trustReason',
            itemtype: { type: 'string' },
            optional: true
        },
        {
            itemprop: 'verificationMethod',
            itemtype: { type: 'string' },
            optional: true
        },
        {
            itemprop: 'permissions',
            itemtype: { type: 'stringifiable' }, // JSON-serializable object
            optional: true
        },
        {
            itemprop: 'issuedAt',
            itemtype: { type: 'number' }
        },
        {
            itemprop: 'serialNumber',
            itemtype: { type: 'string' }
        },
        {
            itemprop: 'version',
            itemtype: { type: 'number' }
        },
        {
            itemprop: 'trustRelationship',
            itemtype: { type: 'string' }, // Hash of TrustRelationship
            optional: true
        },
        {
            itemprop: 'signature',
            itemtype: { type: 'string' },
            optional: true
        }
    ]
};
/**
 * Reverse map for querying TrustKeysCertificate objects
 */
export const TrustKeysCertificateReverseMap = [
    'TrustKeysCertificate',
    new Set(['id', 'subject', 'issuer', 'subjectPublicKey'])
];
//# sourceMappingURL=TrustKeysCertificate.js.map