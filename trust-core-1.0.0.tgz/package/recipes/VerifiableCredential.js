/**
 * VerifiableCredential Recipe
 *
 * W3C Verifiable Credentials v2.0 compatible credential storage.
 * Stores VCs as ONE.core objects for synchronization and persistence.
 */
/**
 * ONE.core recipe definition for VerifiableCredential
 */
export const VerifiableCredentialRecipe = {
    $type$: 'Recipe',
    name: 'VerifiableCredential',
    rule: [
        {
            itemprop: '@context',
            itemtype: {
                type: 'set',
                item: { type: 'string' }
            }
        },
        {
            itemprop: 'id',
            isId: true, // Makes this versioned with stable ID
            itemtype: { type: 'string' }
        },
        {
            itemprop: 'type',
            itemtype: {
                type: 'set',
                item: { type: 'string' }
            }
        },
        {
            itemprop: 'issuer',
            itemtype: { type: 'stringifiable' } // Can be string or object
        },
        {
            itemprop: 'issuanceDate',
            itemtype: { type: 'string' }
        },
        {
            itemprop: 'expirationDate',
            itemtype: { type: 'string' },
            optional: true
        },
        {
            itemprop: 'credentialSubject',
            itemtype: { type: 'stringifiable' } // JSON-serializable object
        },
        {
            itemprop: 'proof',
            itemtype: { type: 'stringifiable' }, // JSON-serializable object
            optional: true
        },
        {
            itemprop: 'credentialStatus',
            itemtype: { type: 'stringifiable' }, // JSON-serializable object
            optional: true
        },
        {
            itemprop: '_oneMetadata',
            itemtype: { type: 'stringifiable' }, // JSON-serializable object
            optional: true
        }
    ]
};
/**
 * Reverse map for querying VerifiableCredential objects
 */
export const VerifiableCredentialReverseMap = [
    'VerifiableCredential',
    new Set(['id'])
];
//# sourceMappingURL=VerifiableCredential.js.map