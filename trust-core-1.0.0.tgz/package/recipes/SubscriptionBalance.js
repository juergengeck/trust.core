/**
 * SubscriptionBalance Recipe
 *
 * Tracks user's subscription balance and deposit history.
 * Stored as a versioned object keyed by user's Person ID.
 */
/**
 * SubscriptionBalance Recipe Definition
 */
export const SubscriptionBalanceRecipe = {
    $type$: 'Recipe',
    name: 'SubscriptionBalance',
    rule: [
        {
            itemprop: 'userId',
            isId: true, // Makes this a versioned object
            itemtype: {
                type: 'referenceToId',
                allowedTypes: new Set(['Person'])
            }
        },
        {
            itemprop: 'balance',
            itemtype: { type: 'number' }
        },
        {
            itemprop: 'totalDeposited',
            itemtype: { type: 'number' }
        },
        {
            itemprop: 'lastUpdated',
            itemtype: { type: 'number' }
        },
        {
            itemprop: 'version',
            itemtype: { type: 'number' }
        }
    ]
};
/**
 * Reverse map for SubscriptionBalance (for querying by userId)
 */
export const SubscriptionBalanceReverseMap = [
    'SubscriptionBalance',
    new Set(['userId'])
];
export default SubscriptionBalanceRecipe;
//# sourceMappingURL=SubscriptionBalance.js.map