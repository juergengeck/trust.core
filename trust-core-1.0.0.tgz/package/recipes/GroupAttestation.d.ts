/**
 * GroupAttestation Recipe
 *
 * ONE.core recipe for group membership attestation certificates.
 * These certificates attest that a group exists and who its members are.
 */
import type { Recipe, OneObjectTypeNames, Person } from '@refinio/one.core/lib/recipes.js';
import type { SHA256Hash, SHA256IdHash } from '@refinio/one.core/lib/util/type-checks.js';
/**
 * GroupAttestation - Unversioned certificate attesting to group membership
 *
 * This certificate is created by the group owner and distributed to members.
 * It serves as proof of group existence and membership list.
 */
export interface GroupAttestation {
    $type$: 'GroupAttestation';
    groupId: string;
    groupHash: SHA256Hash<any>;
    members: SHA256IdHash<Person>[];
    issuer: SHA256IdHash<Person>;
    issuedAt: number;
    validUntil: number;
}
/**
 * ONE.core recipe definition for GroupAttestation
 */
export declare const GroupAttestationRecipe: Recipe;
/**
 * Reverse map for querying GroupAttestation objects
 */
export declare const GroupAttestationReverseMap: [OneObjectTypeNames, Set<string>];
declare module '@OneObjectInterfaces' {
    interface OneUnversionedObjectInterfaces {
        GroupAttestation: GroupAttestation;
    }
}
//# sourceMappingURL=GroupAttestation.d.ts.map