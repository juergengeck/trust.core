/**
 * CertificateRegistry Recipe
 *
 * ONE.core recipe for storing certificate registries.
 * Certificates are versioned so they can be revoked by creating new versions
 * with updated validity periods. The registry itself is versioned for auditability.
 */
/**
 * ONE.core recipe definition for CertificateRegistry
 */
export const CertificateRegistryRecipe = {
    $type$: 'Recipe',
    name: 'CertificateRegistry',
    rule: [
        {
            itemprop: 'id',
            isId: true, // Makes this a versioned object
            itemtype: { type: 'string' }
        },
        {
            itemprop: 'certificates',
            itemtype: {
                type: 'set', // Use set to avoid duplicates
                item: {
                    type: 'string' // Store certificate hashes as strings
                }
            }
        }
    ]
};
/**
 * Reverse map for querying CertificateRegistry objects
 */
export const CertificateRegistryReverseMap = [
    'CertificateRegistry',
    new Set(['id']) // Index by id for fast lookups
];
//# sourceMappingURL=CertificateRegistry.js.map