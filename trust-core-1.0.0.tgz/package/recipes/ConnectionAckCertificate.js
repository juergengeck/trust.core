/**
 * ConnectionAckCertificate Recipe
 *
 * Issued after verifying an encrypted nonce from ProfileResponse.
 * The decrypted nonce proves key ownership, establishing trust.
 */
/**
 * ONE.core recipe definition for ConnectionAckCertificate
 */
export const ConnectionAckCertificateRecipe = {
    $type$: 'Recipe',
    name: 'ConnectionAckCertificate',
    rule: [
        {
            itemprop: 'id',
            isId: true,
            itemtype: { type: 'string' }
        },
        {
            itemprop: 'responder',
            itemtype: { type: 'referenceToId', allowedTypes: new Set(['Person']) }
        },
        {
            itemprop: 'challenger',
            itemtype: { type: 'referenceToId', allowedTypes: new Set(['Person']) }
        },
        {
            itemprop: 'nonce',
            itemtype: { type: 'string' }
        },
        {
            itemprop: 'profileResponse',
            itemtype: { type: 'referenceToObj', allowedTypes: new Set(['ProfileResponse']) }
        },
        {
            itemprop: 'created',
            itemtype: { type: 'number' }
        },
        {
            itemprop: 'status',
            itemtype: { type: 'string' }
        },
        {
            itemprop: 'license',
            itemtype: { type: 'referenceToObj', allowedTypes: new Set(['License']) }
        },
        {
            itemprop: 'validUntil',
            itemtype: { type: 'number' }
        },
        {
            itemprop: 'version',
            itemtype: { type: 'number' }
        }
    ]
};
/**
 * Reverse map for querying ConnectionAckCertificate objects
 */
export const ConnectionAckCertificateReverseMap = [
    'ConnectionAckCertificate',
    new Set(['id', 'responder', 'challenger', 'profileResponse'])
];
//# sourceMappingURL=ConnectionAckCertificate.js.map