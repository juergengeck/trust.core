/**
 * Recipe Exports
 *
 * Export all trust.core recipes for registration with ONE.core
 */
export { TrustRelationshipRecipe, TrustRelationshipReverseMap } from './TrustRelationship.js';
export { GroupAttestationRecipe, GroupAttestationReverseMap } from './GroupAttestation.js';
export { CertificateRegistryRecipe, CertificateRegistryReverseMap } from './CertificateRegistry.js';
export { CertificateRecipe, CertificateReverseMap } from './Certificate.js';
export { VerifiableCredentialRecipe, VerifiableCredentialReverseMap } from './VerifiableCredential.js';
export { SubscriptionCertificateRecipe, SubscriptionCertificateReverseMap } from './SubscriptionCertificate.js';
export { SubscriptionBalanceRecipe, SubscriptionBalanceReverseMap } from './SubscriptionBalance.js';
export { ProfileResponseRecipe, ProfileResponseReverseMap } from './ProfileResponse.js';
export { ConnectionAckCertificateRecipe, ConnectionAckCertificateReverseMap } from './ConnectionAckCertificate.js';
// Import for convenience arrays
import { TrustRelationshipRecipe, TrustRelationshipReverseMap } from './TrustRelationship.js';
import { GroupAttestationRecipe, GroupAttestationReverseMap } from './GroupAttestation.js';
import { CertificateRegistryRecipe, CertificateRegistryReverseMap } from './CertificateRegistry.js';
import { CertificateRecipe, CertificateReverseMap } from './Certificate.js';
// TrustKeysCertificate - Use ONE.models' version (auto-registered)
import { VerifiableCredentialRecipe, VerifiableCredentialReverseMap } from './VerifiableCredential.js';
import { SubscriptionCertificateRecipe, SubscriptionCertificateReverseMap } from './SubscriptionCertificate.js';
import { SubscriptionBalanceRecipe, SubscriptionBalanceReverseMap } from './SubscriptionBalance.js';
import { ProfileResponseRecipe, ProfileResponseReverseMap } from './ProfileResponse.js';
import { ConnectionAckCertificateRecipe, ConnectionAckCertificateReverseMap } from './ConnectionAckCertificate.js';
/**
 * All recipes for batch registration
 *
 * NOTE: TrustKeysCertificate is NOT included here - it's auto-registered by ONE.models
 * via registerLicense() when the module is imported. Including it would cause duplicate
 * registration errors.
 */
export const AllRecipes = [
    TrustRelationshipRecipe,
    GroupAttestationRecipe,
    CertificateRegistryRecipe,
    CertificateRecipe,
    // TrustKeysCertificateRecipe - REMOVED: Use ONE.models' version
    VerifiableCredentialRecipe,
    SubscriptionCertificateRecipe,
    SubscriptionBalanceRecipe,
    ProfileResponseRecipe,
    ConnectionAckCertificateRecipe
];
/**
 * All reverse maps for batch registration
 *
 * NOTE: TrustKeysCertificateReverseMap is NOT included - managed by ONE.models
 */
export const AllReverseMaps = [
    TrustRelationshipReverseMap,
    GroupAttestationReverseMap,
    CertificateRegistryReverseMap,
    CertificateReverseMap,
    // TrustKeysCertificateReverseMap - REMOVED: Use ONE.models' version
    VerifiableCredentialReverseMap,
    SubscriptionCertificateReverseMap,
    SubscriptionBalanceReverseMap,
    ProfileResponseReverseMap,
    ConnectionAckCertificateReverseMap
];
//# sourceMappingURL=index.js.map