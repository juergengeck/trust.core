/**
 * Certificate Recipe
 *
 * Base certificate type for the trust system.
 * Time-bound with ONE.core versioning for lifecycle management.
 */
/**
 * ONE.core recipe definition for Certificate
 */
export const CertificateRecipe = {
    $type$: 'Recipe',
    name: 'Certificate',
    rule: [
        {
            itemprop: 'id',
            isId: true, // Makes this versioned with stable ID
            itemtype: { type: 'string' }
        },
        {
            itemprop: 'certificateType',
            itemtype: { type: 'string' }
        },
        {
            itemprop: 'status',
            itemtype: { type: 'string' }
        },
        {
            itemprop: 'subject',
            itemtype: { type: 'string' } // Can be Person ID or other identifier
        },
        {
            itemprop: 'subjectPublicKey',
            itemtype: { type: 'string' }
        },
        {
            itemprop: 'issuer',
            itemtype: { type: 'referenceToId', allowedTypes: new Set(['Person']) }
        },
        {
            itemprop: 'issuerPublicKey',
            itemtype: { type: 'string' }
        },
        {
            itemprop: 'validFrom',
            itemtype: { type: 'number' }
        },
        {
            itemprop: 'validUntil',
            itemtype: { type: 'number' }
        },
        {
            itemprop: 'issuedBy',
            itemtype: { type: 'string' }, // Hash of parent certificate
            optional: true
        },
        {
            itemprop: 'chainDepth',
            itemtype: { type: 'number' }
        },
        {
            itemprop: 'claims',
            itemtype: { type: 'stringifiable' }, // JSON-serializable object
            optional: true
        },
        {
            itemprop: 'issuedAt',
            itemtype: { type: 'number' }
        },
        {
            itemprop: 'serialNumber',
            itemtype: { type: 'string' }
        },
        {
            itemprop: 'version',
            itemtype: { type: 'number' }
        },
        {
            itemprop: 'signature',
            itemtype: { type: 'string' },
            optional: true
        }
    ]
};
/**
 * Reverse map for querying Certificate objects
 */
export const CertificateReverseMap = [
    'Certificate',
    new Set(['id', 'subject', 'issuer', 'certificateType'])
];
//# sourceMappingURL=Certificate.js.map