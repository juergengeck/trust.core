/**
 * SubscriptionCertificate Recipe
 *
 * Certificate for identity subscription service on lama.one domains.
 *
 * IMPORTANT: This is NOT a software license - LAMA software is free and open.
 * This is an IDENTITY ATTESTATION service - a ROOT OF TRUST for 3rd parties.
 *
 * What you're buying: Time-bound proof that you own a specific identity
 * Example: claude@glue.one for 1€/month or 10€/year
 *
 * Use case: When interacting with unknown 3rd parties, share your certificate
 * to prove you control this identity on lama.one infrastructure.
 */
import type { Recipe, OneObjectTypeNames } from '@refinio/one.core/lib/recipes.js';
import type { Certificate } from './Certificate.js';
/**
 * Subscription Tier (duration-based pricing)
 */
export type SubscriptionTier = 'monthly' | 'yearly';
/**
 * Subscription Status
 */
export type SubscriptionStatus = 'active' | 'expired' | 'cancelled' | 'pending';
/**
 * SubscriptionCertificate
 *
 * Time-bound identity certificate proving ownership of a subscribed identity.
 * Example: claude@glue.one subscribed for 1 year at 10€
 *
 * Purpose: Root of trust for unknown 3rd parties
 * - Cryptographically proves you control this identity on lama.one
 * - Can be verified via QR code or URL
 * - W3C VC compatible for interoperability
 * - Works with any identity-aware system
 *
 * Uses Certificate's versioning for lifecycle management:
 * - New subscription: Create certificate with appropriate validUntil
 * - Renewal: Extend certificate (new version with later validUntil)
 * - Cancellation: Revoke certificate (new version with status='revoked')
 * - Expiration: Certificate becomes invalid when validUntil < Date.now()
 */
export interface SubscriptionCertificate extends Omit<Certificate, '$type$' | 'certificateType' | 'claims'> {
    $type$: 'SubscriptionCertificate';
    certificateType: 'identity';
    claims: {
        identity: string;
        domain: string;
        localPart: string;
        tier: SubscriptionTier;
        priceEur: number;
        subscriptionStatus: SubscriptionStatus;
        paymentId: string;
        depositAmount: number;
        autoRenew: boolean;
        service: string;
        [key: string]: any;
    };
}
/**
 * ONE.core recipe definition for SubscriptionCertificate
 */
export declare const SubscriptionCertificateRecipe: Recipe;
/**
 * Reverse map for querying SubscriptionCertificate objects
 */
export declare const SubscriptionCertificateReverseMap: [OneObjectTypeNames, Set<string>];
declare module '@OneObjectInterfaces' {
    interface OneIdObjectInterfaces {
        SubscriptionCertificate: Pick<SubscriptionCertificate, 'id' | '$type$'>;
    }
    interface OneVersionedObjectInterfaces {
        SubscriptionCertificate: SubscriptionCertificate;
    }
}
//# sourceMappingURL=SubscriptionCertificate.d.ts.map