/**
 * GroupAttestation Recipe
 *
 * ONE.core recipe for group membership attestation certificates.
 * These certificates attest that a group exists and who its members are.
 */
/**
 * ONE.core recipe definition for GroupAttestation
 */
export const GroupAttestationRecipe = {
    $type$: 'Recipe',
    name: 'GroupAttestation',
    rule: [
        {
            itemprop: 'groupId',
            itemtype: { type: 'string' }
        },
        {
            itemprop: 'groupHash',
            itemtype: { type: 'string' }
        },
        {
            itemprop: 'members',
            itemtype: {
                type: 'set',
                item: {
                    type: 'referenceToId',
                    allowedTypes: new Set(['Person'])
                }
            }
        },
        {
            itemprop: 'issuer',
            itemtype: { type: 'referenceToId', allowedTypes: new Set(['Person']) }
        },
        {
            itemprop: 'issuedAt',
            itemtype: { type: 'number' }
        },
        {
            itemprop: 'validUntil',
            itemtype: { type: 'number' }
        }
    ]
};
/**
 * Reverse map for querying GroupAttestation objects
 */
export const GroupAttestationReverseMap = [
    'GroupAttestation',
    new Set(['groupId', 'issuer'])
];
//# sourceMappingURL=GroupAttestation.js.map