/**
 * Certificate Recipe
 *
 * Base certificate type for the trust system.
 * Time-bound with ONE.core versioning for lifecycle management.
 */
import type { Recipe, OneObjectTypeNames, Person } from '@refinio/one.core/lib/recipes.js';
import type { SHA256Hash, SHA256IdHash } from '@refinio/one.core/lib/util/type-checks.js';
/**
 * Certificate Type
 */
export type CertificateType = 'identity' | 'device' | 'service' | 'attestation' | 'delegation' | 'revocation';
/**
 * Certificate Status
 */
export type CertificateStatus = 'valid' | 'expired' | 'revoked' | 'suspended';
/**
 * Base Certificate
 *
 * Versioned object with ID property for lifecycle management:
 * - Extensions: New version with later validUntil
 * - Reductions: New version with earlier validUntil
 * - Revocation: New version with status='revoked' and validUntil in past
 *
 * Each certificate has a stable ID (SHA256IdHash), and versions represent
 * the certificate's lifecycle. Same certificate, different time bounds.
 */
export interface Certificate {
    $type$: 'Certificate';
    id: string;
    certificateType: CertificateType;
    status: CertificateStatus;
    subject: SHA256IdHash<Person> | string;
    subjectPublicKey: string;
    issuer: SHA256IdHash<Person>;
    issuerPublicKey: string;
    validFrom: number;
    validUntil: number;
    issuedBy?: SHA256Hash<Certificate>;
    chainDepth: number;
    claims?: {
        name?: string;
        email?: string;
        domain?: string;
        canSign?: boolean;
        canIssue?: boolean;
        canRevoke?: boolean;
        purposes?: string[];
        scope?: string;
        [key: string]: any;
    };
    issuedAt: number;
    serialNumber: string;
    version: number;
    signature?: string;
}
/**
 * ONE.core recipe definition for Certificate
 */
export declare const CertificateRecipe: Recipe;
/**
 * Reverse map for querying Certificate objects
 */
export declare const CertificateReverseMap: [OneObjectTypeNames, Set<string>];
declare module '@OneObjectInterfaces' {
    interface OneIdObjectInterfaces {
        Certificate: Pick<Certificate, 'id' | '$type$'>;
    }
    interface OneVersionedObjectInterfaces {
        Certificate: Certificate;
    }
}
//# sourceMappingURL=Certificate.d.ts.map