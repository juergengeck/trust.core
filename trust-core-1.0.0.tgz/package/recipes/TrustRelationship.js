/**
 * TrustRelationship Recipe
 *
 * ONE.core recipe for storing trust relationships between devices/persons.
 * Integrates with ONE.models TrustedKeysManager and TrustKeysCertificate.
 */
/**
 * ONE.core recipe definition for TrustRelationship
 */
export const TrustRelationshipRecipe = {
    $type$: 'Recipe',
    name: 'TrustRelationship',
    rule: [
        {
            itemprop: '$version$',
            itemtype: { type: 'string' }
        },
        {
            itemprop: 'id',
            itemtype: { type: 'string' },
            isId: true
        },
        {
            itemprop: 'peer',
            itemtype: { type: 'referenceToId', allowedTypes: new Set(['Person']) }
        },
        {
            itemprop: 'peerPublicKey',
            itemtype: { type: 'string' }
        },
        {
            itemprop: 'status',
            itemtype: { type: 'string' }
        },
        {
            itemprop: 'trustLevel',
            itemtype: { type: 'string' },
            optional: true
        },
        {
            itemprop: 'permissions',
            itemtype: { type: 'stringifiable' }, // JSON-serializable object
            optional: true
        },
        {
            itemprop: 'establishedAt',
            itemtype: { type: 'string' }
        },
        {
            itemprop: 'lastVerified',
            itemtype: { type: 'string' },
            optional: true
        },
        {
            itemprop: 'validUntil',
            itemtype: { type: 'string' },
            optional: true
        },
        {
            itemprop: 'reason',
            itemtype: { type: 'string' },
            optional: true
        },
        {
            itemprop: 'context',
            itemtype: { type: 'string' },
            optional: true
        },
        {
            itemprop: 'verificationMethod',
            itemtype: { type: 'string' },
            optional: true
        },
        {
            itemprop: 'verificationProof',
            itemtype: { type: 'string' }, // Store hash as string
            optional: true
        }
    ]
};
/**
 * Reverse map for querying TrustRelationship objects
 */
export const TrustRelationshipReverseMap = [
    'TrustRelationship',
    new Set(['peer']) // Index by peer for fast lookups
];
//# sourceMappingURL=TrustRelationship.js.map