/**
 * ConnectionAckCertificate Recipe
 *
 * Issued after verifying an encrypted nonce from ProfileResponse.
 * The decrypted nonce proves key ownership, establishing trust.
 */
import type { Recipe, OneObjectTypeNames, Person } from '@refinio/one.core/lib/recipes.js';
import type { SHA256Hash, SHA256IdHash } from '@refinio/one.core/lib/util/type-checks.js';
import type { License } from '@refinio/one.models/lib/recipes/Certificates/License.js';
import type { ProfileResponse } from './ProfileResponse.js';
/**
 * ConnectionAckCertificate
 *
 * Versioned certificate proving successful handshake completion.
 * Contains the decrypted nonce as proof of key ownership.
 */
export interface ConnectionAckCertificate {
    $type$: 'ConnectionAckCertificate';
    /** Stable ID for versioning (format: "connack:{responder}:{challenger}:{timestamp}") */
    id: string;
    /** Who responded (initiated the connection) */
    responder: SHA256IdHash<Person>;
    /** Who acknowledged (proved key ownership) */
    challenger: SHA256IdHash<Person>;
    /** Decrypted nonce proving key ownership (hex) */
    nonce: string;
    /** Reference to the ProfileResponse being acknowledged */
    profileResponse: SHA256Hash<ProfileResponse>;
    /** When this certificate was issued (Unix timestamp ms) */
    created: number;
    /** Certificate status */
    status: 'valid' | 'expired' | 'revoked';
    /** License for this certificate */
    license: SHA256Hash<License>;
    /** Validity period end (Unix timestamp ms) */
    validUntil: number;
    /** Certificate version (increments with updates) */
    version: number;
}
/**
 * ONE.core recipe definition for ConnectionAckCertificate
 */
export declare const ConnectionAckCertificateRecipe: Recipe;
/**
 * Reverse map for querying ConnectionAckCertificate objects
 */
export declare const ConnectionAckCertificateReverseMap: [OneObjectTypeNames, Set<string>];
declare module '@OneObjectInterfaces' {
    interface OneIdObjectInterfaces {
        ConnectionAckCertificate: Pick<ConnectionAckCertificate, 'id' | '$type$'>;
    }
    interface OneVersionedObjectInterfaces {
        ConnectionAckCertificate: ConnectionAckCertificate;
    }
}
//# sourceMappingURL=ConnectionAckCertificate.d.ts.map