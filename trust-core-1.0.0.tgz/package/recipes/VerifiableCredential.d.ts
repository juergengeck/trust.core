/**
 * VerifiableCredential Recipe
 *
 * W3C Verifiable Credentials v2.0 compatible credential storage.
 * Stores VCs as ONE.core objects for synchronization and persistence.
 */
import type { Recipe, OneObjectTypeNames } from '@refinio/one.core/lib/recipes.js';
import type { SHA256Hash } from '@refinio/one.core/lib/util/type-checks.js';
/**
 * W3C Verifiable Credential
 *
 * Standard-compliant credential that can be presented externally.
 * Stored as versioned object in ONE.core, can be exported as JSON-LD.
 *
 * This is the presentation layer for Certificate objects - any Certificate
 * can be converted to a VC and vice versa using VCBridge.
 */
export interface VerifiableCredential {
    $type$: 'VerifiableCredential';
    '@context': string[];
    id: string;
    type: string[];
    issuer: string | {
        id: string;
        name?: string;
    };
    issuanceDate: string;
    expirationDate?: string;
    credentialSubject: {
        id: string;
        [key: string]: any;
    };
    proof?: {
        type: string;
        created: string;
        proofPurpose: string;
        verificationMethod: string;
        proofValue: string;
    };
    credentialStatus?: {
        id: string;
        type: string;
    };
    _oneMetadata?: {
        certificateHash?: SHA256Hash<any>;
        version?: number;
        syncedAt?: number;
    };
}
/**
 * ONE.core recipe definition for VerifiableCredential
 */
export declare const VerifiableCredentialRecipe: Recipe;
/**
 * Reverse map for querying VerifiableCredential objects
 */
export declare const VerifiableCredentialReverseMap: [OneObjectTypeNames, Set<string>];
declare module '@OneObjectInterfaces' {
    interface OneIdObjectInterfaces {
        VerifiableCredential: Pick<VerifiableCredential, 'id' | '$type$'>;
    }
    interface OneVersionedObjectInterfaces {
        VerifiableCredential: VerifiableCredential;
    }
}
//# sourceMappingURL=VerifiableCredential.d.ts.map